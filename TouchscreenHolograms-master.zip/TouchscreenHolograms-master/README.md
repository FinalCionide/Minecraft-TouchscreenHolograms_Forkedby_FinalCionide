Touchscreen Holograms
===================

Bukkit Page: https://dev.bukkit.org/projects/touchscreen-holograms

## License
Touchscreen Holograms is free software/open source, and is distributed under the [GPL 3.0 License](https://opensource.org/licenses/GPL-3.0). It contains third-party code, see the included THIRD-PARTY.txt file for the license information on third-party code.
